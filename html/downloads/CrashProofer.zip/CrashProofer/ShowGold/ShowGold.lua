--
--ShowGold
--
--Written by Tiok - US Thrall


function ShowGold_RegisterEvents()
    this:RegisterEvent("ADDON_LOADED")
    this:RegisterEvent("PLAYER_ENTERING_WORLD")
    this:RegisterEvent("PLAYER_MONEY")
    --add event registrations here
end

function ShowGold_Init()
    --If there is no data for this addon in CrashProofer yet, add a Start record.
    if (not CrashProofer_AddonHasData("ShowGold")) then
        local record = {}
        record.Type = ShowGold_Start

        CrashProofer_AddRecord("ShowGold",record)
    end
end

function ShowGold_RegisterSlashCommands()
    SLASH_SHOWGOLD1 = "/showgold";
    SlashCmdList.SHOWGOLD = ShowGold_SlashCommand
end

function ShowGold_SlashCommand(character,editbox)
    --Did they ask to compress the data?
    if (character == "compress") then
        ShowGold_CompressData()
        return
    end

    if (character == "") then
        --Usage message, if they didn't enter a character name.
        DEFAULT_CHAT_FRAME:AddMessage("Try /showgold <characterName> (without the brackets)")
        return
    end
    
    if (ShowGold_DB[GetRealmName()][character] == nil) then
        --If we have no record for the given character, say so.
        DEFAULT_CHAT_FRAME:AddMessage(character.." has no record on this server yet.")
    else
        --If we DO have a record, display the gold amount.
        DEFAULT_CHAT_FRAME:AddMessage(character.." has "..ShowGold_DB[GetRealmName()][character].." gold!")
    end
end

function ShowGold_OnLoad()
    ShowGold_RegisterEvents();
    ShowGold_RegisterSlashCommands();
end

function ShowGold_OnEvent()
    if ( event == "ADDON_LOADED" ) and ( arg1 == "ShowGold" ) then
        ShowGold_Init();
    elseif (event == "PLAYER_ENTERING_WORLD") or (event == "PLAYER_MONEY") then
        ShowGold_RecordGoldAmount()
    end
end

function ShowGold_RecordGoldAmount()
    local record = {}
    record.Type = ShowGold_GoldAmount
    record.Char = UnitName("player")

    --Since realm names can be more than one word,
    --we will split it into multiple fields.
    local realmName = GetRealmName()
    local wordNum = 1
    for _,word,_ in string.gmatch(realmName,"([^%a]*)(%a+)([^%a]*)") do
        record["Realm"..wordNum] = word
        wordNum = wordNum + 1
    end

    --GetMoney() returns copper, so we convert it to gold.
    record.Gold = math.floor(GetMoney()/10000)

    --And now add the record to CrashProofer.
    CrashProofer_AddRecord("ShowGold",record)
end

function ShowGold_CompressData()
    CrashProofer_BeginCompression("ShowGold")

    CrashProofer_AddRecord("ShowGold",{Type=ShowGold_Start})

    for realmName,characters in pairs(ShowGold_DB) do
        for charName,gold in pairs(characters) do
            local record = {}
            record.Type = ShowGold_GoldAmount
            record.Char = charName
            record.Gold = gold

            --Split the realm name.
            local wordNum = 1
            for _,word,_ in string.gmatch(realmName,"([^%a]*)(%a+)([^%a]*)") do
                record["Realm"..wordNum] = word
                wordNum = wordNum + 1
            end

            --And add the compressed record.
            CrashProofer_AddRecord("ShowGold",record)
        end
    end

    CrashProofer_EndCompression("ShowGold")
end
