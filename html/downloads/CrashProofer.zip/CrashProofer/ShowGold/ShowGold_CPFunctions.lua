--Record Type abbreviations
ShowGold_Start      = "S"
ShowGold_GoldAmount = "GA"


--Record Functions

function ShowGold_OnStart(record)
    ShowGold_DB = {}
end

function ShowGold_OnGoldAmount(record)
    --Contains:
    --str Char   - the name of the character whose record this is.
    --str Realm# - the name of the realm this character is on, split into words starting with Realm1.
    --num Gold   - the amount of gold this character has.

    --Make sure Gold is a number.
    record.Gold = tonumber(record.Gold)

    --Reassemble the realm name into a single string.
    local realmName = record.Realm1
    local nextWord = 2
    while (record["Realm"..nextWord] ~= nil) do
        realmName = realmName.." "..record["Realm"..nextWord]
        nextWord = nextWord + 1
    end

    --And put the data into our table.
    if (ShowGold_DB[realmName] == nil) then
        ShowGold_DB[realmName] = {}
    end

    ShowGold_DB[realmName][record.Char] = record.Gold
end


--Record Type registrations.
CrashProofer_RegisterRecordType("ShowGold", ShowGold_Start,      ShowGold_OnStart)
CrashProofer_RegisterRecordType("ShowGold", ShowGold_GoldAmount, ShowGold_OnGoldAmount)
