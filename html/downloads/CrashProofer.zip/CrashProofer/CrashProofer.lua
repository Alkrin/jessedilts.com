--CrashProofer

CRASHPROOFER_PREFIX = "CP";
CP_ANNOUNCE = "ANN"
CP_REQUEST  = "REQ"
CP_RECORD   = "REC"

--Contains tables by Addon name.  Each sub-table contains name-keyed functions whose value is the function to run for that record type.
CP_RECORD_FUNCTIONS = {}
--Keys are the names of addons currently being compressed.  Value is a table of records to replace the old ones when compression is done.
CP_NOW_COMPRESSING = {}
--Key = addonName, Value = number of records needed to be up to date.
CP_RECORDS_EXPECTED = {}
--Key = addonName, Value = time when you can start adding new records for it.
CP_CAN_ADD_RECORDS = {}
--Contains tables with pending records by addon name.  Otherwise identical to CP_DB.
CP_PENDING_RECORDS = {}
--Key=addonName,Val=last record number whose function has been called.
--CP_LAST_RECORD_FUNCTION_RUN = {}

--Contains all queued, outgoing packets.
CP_RECORD_REQUESTS = {}

--Contains the names of all addons that have been loaded so far.
CP_ADDONS_LOADED = {}


function CrashProofer_RegisterEvents()
    this:RegisterEvent("ADDON_LOADED")
    this:RegisterEvent("CHAT_MSG_ADDON") --default networking support in addons!
    --add event registrations here
end

function CrashProofer_Init()
    --add variable initializations here
    if (CP_DB == nil) then CP_DB = {} end
    if (CP_COMPRESSION_DATES == nil) then CP_COMPRESSION_DATES = {} end
    if (CP_LAST_RECORD_FUNCTION_RUN == nil) then CP_LAST_RECORD_FUNCTION_RUN = {} end
	if (CP_RECORDS_EXPECTED == nil) then CP_RECORDS_EXPECTED = {} end
	if (#CP_RECORDS_EXPECTED == 0) then
		for addonName,records in pairs(CP_DB) do
			CP_RECORDS_EXPECTED[addonName] = #records
		end
	end
	if (CP_CAN_ADD_RECORDS == nil) then CP_CAN_ADD_RECORDS = {} end

	--Before we announce records, set up the time delay to wait for announces.
	for addonName,records in pairs(CP_DB) do
		CP_CAN_ADD_RECORDS[addonName] = GetTime() + 30
	end

	--If we have any records, we'll announce them here.
	--If we don't, we'll request them later.
    CrashProofer_AnnounceAll()

    CP_INITIALIZED = true
end

function CrashProofer_RegisterSlashCommands()
    SLASH_cpStuff1 = "/cp";
    SlashCmdList["cpStuff"] = function() CrashProofer_SlashCommand(); end

	SLASH_cpDump1 = "/cpdump";
	SlashCmdList["cpDump"] = CPDump;

	SLASH_cpCount1 = "/cpcount";
	SlashCmdList["cpCount"] = CPCount;

    --add slash command registrations here
end

function CrashProofer_SlashCommand()
    --Do your slash command code here.
end


function CrashProofer_OnLoad()
    CrashProofer_RegisterEvents();
    CrashProofer_RegisterSlashCommands();
end

function CrashProofer_OnEvent()
    if ( event == "ADDON_LOADED" ) then
        CrashProofer_OnAddonLoaded(arg1)
    elseif( event == "CHAT_MSG_ADDON" ) then
        if(arg1 == CRASHPROOFER_PREFIX) then
            CrashProofer_NetworkEvent(arg2, arg3, arg4);
        end
    end
end

function CrashProofer_SendNetworkMessage(msg, destination)
    if(destination == "GUILD") then
        if(IsInGuild()) then
             SendAddonMessage(CRASHPROOFER_PREFIX,msg,destination);
        end
    elseif(destination == "RAID") then
        if(GetNumRaidMembers()) then
            SendAddonMessage(CRASHPROOFER_PREFIX,msg,destination);
        end
    elseif(destination == "PARTY") then
        if(GetNumPartyMembers()) then
            SendAddonMessage(CRASHPROOFER_PREFIX,msg,destination);
        end
    elseif(destination == "BATTLEGROUND") then
        if(GetBattlefieldInstanceRunTime()) then
            SendAddonMessage(CRASHPROOFER_PREFIX,msg,destination);
        end
    end
end

function CrashProofer_NetworkEvent(msg, channel, sender)
    if(sender ~= UnitName("player")) then -- process only network events from others, ignore ourselves.
        --So we just got a packet from another CP user.  What kind of packet was it?
        local packetType = string.sub(msg,1,3)
        if (packetType == CP_RECORD) then
            CrashProofer_HandleRecordPacket(msg)
        elseif (packetType == CP_REQUEST) then
            CrashProofer_HandleRequestPacket(msg)
        elseif (packetType == CP_ANNOUNCE) then
            CrashProofer_HandleAnnouncePacket(msg)
        end
    end
end

--An empty function for record types with no function of their own.
function CrashProofer_EmptyFunction()
end

--addonName      = string name of the addon for which the record type is being registered
--typeName       = string name of this new record type
--recordFunction = function to be called when this record type is recorded, or nil if no action to be taken
function CrashProofer_RegisterRecordType(addonName,typeName,recordFunction)
    if (CP_RECORD_FUNCTIONS == nil) then CP_RECORD_FUNCTIONS = {} end
    if (CP_RECORD_FUNCTIONS[addonName] == nil) then CP_RECORD_FUNCTIONS[addonName] = {} end

    --This will overwrite a previously registered function if one exists, else create a new record type.
    if (recordFunction == nil) then recordFunction = CrashProofer_EmptyFunction end
    CP_RECORD_FUNCTIONS[addonName][typeName] = recordFunction
end

--addonName = string name of the addon which is adding the record.
--record    = table containing the record data.  Only requirement is a string member called "Type" that matches a registered record type for that addon.
--
--Returns true if the record is added, false if the add fails.
function CrashProofer_AddRecord(addonName,record)
    --Make sure the record is valid.
    if (record == nil) then return false end
    if (record.Type == nil) then return false end
    if (CP_RECORD_FUNCTIONS[addonName] == nil) then CP_RECORD_FUNCTIONS[addonName] = {} end
    if (CP_RECORD_FUNCTIONS[addonName][record.Type] == nil) then CP_RECORD_FUNCTIONS[addonName][record.Type] = CrashProofer_EmptyFunction end

    --If you get this far, we have a valid record, so add it and call its function.
    if (CP_DB[addonName] == nil) then 
        CP_DB[addonName] = {}
        CP_COMPRESSION_DATES[addonName] = CrashProofer_GetFullTimeStamp()
        CP_LAST_RECORD_FUNCTION_RUN[addonName] = 0
		CP_RECORDS_EXPECTED[addonName] = 0
    end

	--Make sure we're allowed to add records to this addon.
	--Have to have all of the current records.
	if (#CP_DB[addonName] < CP_RECORDS_EXPECTED[addonName]) then return false end
	--Have to be past the mandatory wait time (to make sure we get announces from others).
	if (CP_CAN_ADD_RECORDS[addonName] > GetTime()) then return false end

    if (CP_NOW_COMPRESSING[addonName] == nil) then
        table.insert(CP_DB[addonName],record)
		--Add one to the expected record count.
		CP_RECORDS_EXPECTED[addonName] = #CP_DB[addonName]
        --And broadcast this new record.
        CrashProofer_SendRecord(addonName,#CP_DB[addonName])
        --Run its function.
        CP_RECORD_FUNCTIONS[addonName][record.Type](record)
        --We assume that you never call AddRecord unless the addon specified has been loaded.
        CP_LAST_RECORD_FUNCTION_RUN[addonName] = #CP_DB[addonName]
    else
        table.insert(CP_NOW_COMPRESSING[addonName],record)
        --We don't broadcast while compressing, or run record functions.

		--Add one to the expected record count.
		CP_RECORDS_EXPECTED[addonName] = #CP_DB[addonName]
    end

	return true
end

function CrashProofer_ClearAllRecords(addonName)
    CP_DB[addonName] = {}
end

function CrashProofer_BeginCompression(addonName)
    CP_NOW_COMPRESSING[addonName] = {}
	CP_RECORDS_EXPECTED[addonName] = 0
end

function CrashProofer_EndCompression(addonName)
    if (CP_NOW_COMPRESSING[addonName] == nil) then return end

    CP_DB[addonName] = CP_NOW_COMPRESSING[addonName]
    CP_NOW_COMPRESSING[addonName] = nil
    CP_COMPRESSION_DATES[addonName] = CrashProofer_GetFullTimeStamp()
    
    --Starts over at record 1.
    CrashProofer_DoFullRecordFunctionSweep(addonName)

    --Announce our newly compressed addon data.
    CrashProofer_AnnounceOne(addonName)
end

function CrashProofer_GetDateTimeStamp()
    local _,month,day,year = CalendarGetDate()

    if (month < 10) then month = "0"..month end
    if (day < 10) then day = "0"..day end

    return year..month..day
end

function CrashProofer_GetFullTimeStamp()
    local hour,minute = GetGameTime()
    if (hour < 10) then hour = "0"..hour end
    if (minute < 10) then minute = "0"..minute end

    return CrashProofer_GetDateTimeStamp()..hour..minute
end

function CrashProofer_AnnounceOne(addonName)
	if (addonName ~= "CRASHPROOFER") then
	    ChatThrottleLib:SendAddonMessage("ALERT",CRASHPROOFER_PREFIX,CP_ANNOUNCE..addonName.." "..CP_COMPRESSION_DATES[addonName]..(#CP_DB[addonName]),"GUILD")
	else
		ChatThrottleLib:SendAddonMessage("ALERT",CRASHPROOFER_PREFIX,CP_ANNOUNCE..addonName.." "..CrashProofer_GetFullTimeStamp()..(0),"GUILD")
	end
end

function CrashProofer_AnnounceAll()
	local count = 0
    for addonName,data in pairs(CP_DB) do
		count = count + 1;
        CrashProofer_AnnounceOne(addonName)
    end

	if (count == 0) then
		D("CrashProofer - First Run, Checking For Other Users");
		CrashProofer_AnnounceOne("CRASHPROOFER");
	end
end

function CrashProofer_Request(addonName,timestamp,firstRecord)
    if (firstRecord == nil) then firstRecord = 1 end

    ChatThrottleLib:SendAddonMessage("NORMAL",CRASHPROOFER_PREFIX,CP_REQUEST..addonName.." "..timestamp..firstRecord,"GUILD")
end

function CrashProofer_SendRecord(addonName,recordNumber)
    local s = CP_RECORD..addonName.." "..CP_COMPRESSION_DATES[addonName]..recordNumber
    --Now to tack on all of the record data.
    for k,v in pairs(CP_DB[addonName][recordNumber]) do
        s = s.." "..k.."="..v
    end

    ChatThrottleLib:SendAddonMessage("BULK",CRASHPROOFER_PREFIX,s,"GUILD")
end

function CrashProofer_ParseRecordPacket(packet)
    local _,_,addonName,timestamp,recordNumber = string.find(packet,CP_RECORD.."(.*) (%d%d%d%d%d%d%d%d%d%d%d%d)(%d*)")
    local record = {}

    for k,v in string.gmatch(packet," ([^%s]*)=([^%s]*)") do
        record[k] = v
    end

    return addonName,timestamp,tonumber(recordNumber),record
end

function CrashProofer_ParseRequestPacket(packet)
    --Splits out the addonName, timestamp, and firstRecord requested.
    local _,_,addonName,timestamp,firstRecord = string.find(packet,CP_REQUEST.."(.*) (%d%d%d%d%d%d%d%d%d%d%d%d)(%d*)")
    return addonName,timestamp,tonumber(firstRecord)
end

function CrashProofer_ParseAnnouncePacket(packet)
    --Splits out the addonName, timestamp, and record count.
    local _,_,addonName,timestamp,recordCount = string.find(packet,CP_ANNOUNCE.."(.*) (%d%d%d%d%d%d%d%d%d%d%d%d)(%d*)")
    return addonName,timestamp,tonumber(recordCount)
end

function CrashProofer_HandleAnnouncePacket(packet)
    local addonName,timestamp,recordCount = CrashProofer_ParseAnnouncePacket(packet)
    --D(addonName.." "..timestamp.." "..recordCount)

	if (addonName == "CRASHPROOFER") then
		--Somebody just installed CrashProofer and has no data at all.  Let them know what they're missing!
		CrashProofer_AnnounceAll()
	elseif (CP_DB[addonName] == nil) then
		--We don't have any data for this addon.
		--First, set up empty data tables for it to fill.
		CP_DB[addonName] = {}
        CP_COMPRESSION_DATES[addonName] = timestamp
        CP_LAST_RECORD_FUNCTION_RUN[addonName] = 0
		CP_RECORDS_EXPECTED[addonName] = recordCount
		CP_PENDING_RECORDS[addonName] = nil
        --We don't have any data for this addon, so request all of it!
        CrashProofer_Request(addonName,timestamp)
    else
        --We have this addon in our DB, so...
        if (timestamp < CP_COMPRESSION_DATES[addonName]) then
            --The other person has older data than us, so let them know there's something new.
            CrashProofer_AnnounceOne(addonName)
        elseif (timestamp > CP_COMPRESSION_DATES[addonName]) then
            --The other person has newer data than us, so let's get it!
			--First, clear out our out-dated info.
			CP_DB[addonName] = {}
			CP_COMPRESSION_DATES[addonName] = timestamp
		    CP_LAST_RECORD_FUNCTION_RUN[addonName] = 0
			CP_PENDING_RECORDS[addonName] = nil
			CP_RECORDS_EXPECTED[addonName] = recordCount
			--And request the newer data.
            CrashProofer_Request(addonName,timestamp)
        else
            --We both have the same dates, so see if either of us is missing records.
            local myRecordCount = #CP_DB[addonName]
            if (recordCount < myRecordCount) then
                --I have records that the other guy doesn't, so let him know!
                CrashProofer_AnnounceOne(addonName)
            elseif (recordCount > myRecordCount) then
				--He has records that I don't, so make sure I get them before I futz anything up!
				if (CP_RECORDS_EXPECTED[addonName] == nil) or (CP_RECORDS_EXPECTED[addonName] < recordCount) then
					CP_RECORDS_EXPECTED[addonName] = recordCount
				end
                --He has records that I don't, so request them!
                CrashProofer_Request(addonName,timestamp,myRecordCount+1)
            else
                --We both have the same number of records, so no updates are necessary.
            end
        end
    end
end

function CrashProofer_HandleRequestPacket(packet)
    local addonName,timestamp,firstRecord = CrashProofer_ParseRequestPacket(packet)

    if (CP_DB[addonName] == nil) then
		--If we get here, then we've gotten a Request without seeing an Announce for the addon.
		--So, call for an Announce packet!  When we get it, we'll request the records ourself.
        CrashProofer_AnnounceOne("CRASHPROOFER")
    else
        --We have this addon in our DB, so...
        if (timestamp < CP_COMPRESSION_DATES[addonName]) then
            --The other person has older data than us, so let them know there's something new.
            CrashProofer_AnnounceOne(addonName)
        elseif (timestamp > CP_COMPRESSION_DATES[addonName]) then
			--If we get here, then we've gotten a Request without seeing an Announce for the addon.
			--So, call for an Announce packet!  When we get it, we'll request the records ourself.
			CrashProofer_AnnounceOne("CRASHPROOFER")
        else
            --They are requesting data with my date, so see if we have anything to send.
            --D("SOMEONE REQUESTED RECORD #"..firstRecord)
            local myRecordCount = #CP_DB[addonName]
            if (firstRecord <= myRecordCount) then
                --I have records that the other guy doesn't, so send them off!
                CP_RECORD_REQUESTS[addonName] = firstRecord
            else
				--If we get here, then we've gotten a Request without seeing an Announce for the addon.
				--So, call for an Announce packet!  When we get it, we'll request the records ourself.
                CrashProofer_AnnounceOne("CRASHPROOFER")
            end
        end
    end
end

function CrashProofer_HandleRecordPacket(packet)
    local addonName,timestamp,recordNumber,record = CrashProofer_ParseRecordPacket(packet)
    --D("RECORD "..recordNumber.." "..timestamp)

    if (CP_DB[addonName] == nil) then
		--If we get here, then we've gotten a Record without seeing an Announce.
		--So, request an Announce!  After we get it, we'll request the records properly ourself.
        CrashProofer_AnnounceOne("CRASHPROOFER")
		return
    end

    --If we get here, then we have have a table for this addon.
    if (timestamp < CP_COMPRESSION_DATES[addonName]) then
        --The other guy was sending out of date data.  Let him know we have something better.
        CrashProofer_AnnounceOne(addonName)
		return
    elseif (timestamp > CP_COMPRESSION_DATES[addonName]) then
		--If we get here, then we've gotten a Record without seeing an Announce.
		--So, request an Announce!  After we get it, we'll request the records properly ourself.
        CrashProofer_AnnounceOne("CRASHPROOFER")
		return
    end

    --If we get here, then we have a Record that matches our current Compression Date for the addon.
    local myRecordCount = #CP_DB[addonName]
    if (recordNumber <= myRecordCount) then
        --The record is one that we already have, so we can ignore it.
    elseif (recordNumber == myRecordCount+1) then
        --The record is the next one after our current dataset, so add it and run its function (if we have one).
		if (CP_RECORDS_EXPECTED[addonName] == #CP_DB[addonName]) then
			CP_RECORDS_EXPECTED[addonName] = #CP_DB[addonName] + 1
		end
        CP_DB[addonName][recordNumber] = record
        if (CP_RECORD_FUNCTIONS[addonName][record.Type]) and (CP_ADDONS_LOADED[addonName]) then
            CP_RECORD_FUNCTIONS[addonName][record.Type](record)
            CP_LAST_RECORD_FUNCTION_RUN[addonName] = myRecordCount
        end
        --Check for any pending records that can now validly be added.
        if (CP_PENDING_RECORDS[addonName] ~= nil) then
            while (true) do
                myRecordCount = #CP_DB[addonName]
                if (CP_PENDING_RECORDS[addonName][myRecordCount + 1] ~= nil) then
                    --If the next needed record is pending, add it!
                    CP_DB[addonName][myRecordCount+1] = CP_PENDING_RECORDS[addonName][myRecordCount+1]
                    CP_PENDING_RECORDS[addonName][myRecordCount + 1] = nil
                    --Run the newly added record's function, if we have one.
                    record = CP_DB[addonName][myRecordCount+1]
                    if (CP_RECORD_FUNCTIONS[addonName][record.Type]) and (CP_ADDONS_LOADED[addonName]) then
                        CP_RECORD_FUNCTIONS[addonName][record.Type](record)
                        CP_LAST_RECORD_FUNCTION_RUN[addonName] = myRecordCount+1
                    end
                else
                    --If the next needed record is NOT pending, we have to wait until it comes in.
                    break
                end
            end            
        end
    else
        --The record is out of sequence, so put it into the pending table until we find the one(s) between our last and this one.
        if (CP_PENDING_RECORDS[addonName] == nil) then CP_PENDING_RECORDS[addonName] = {} end
        CP_PENDING_RECORDS[addonName][recordNumber] = record
        --And now request any missing records.
        CrashProofer_Request(addonName,timestamp,#CP_DB[addonName]+1)
    end
end

function CrashProofer_TableSize(table)
    local count = 0
    for _,_ in pairs(table) do count = count + 1 end
    return count
end

function CPDump()
    for addonName,addonData in pairs(CP_DB) do
        D("DATA FOR "..addonName.." "..CP_COMPRESSION_DATES[addonName])
        for idx,record in ipairs(addonData) do
            D("RECORD #"..idx)
            for k,v in pairs(record) do
                D("  "..k.." = "..v)
            end
        end
    end
end

function CPCount()
    for addonName,addonData in pairs(CP_DB) do
        D(" "..addonName.." "..(#addonData).."/"..(CP_RECORDS_EXPECTED[addonName]).." Records");
    end
end

function CPTest1()
    --Clear all data.
    CP_DB = {}
    CP_COMPRESSION_DATES = {}
    CP_RECORD_FUNCTIONS = {}
    CP_NOW_COMPRESSING = {}
    CP_PENDING_RECORDS = {}
    CP_PACKET_QUEUE = {}
    --Create test data.
    CP_DB["Test"] = {}
    CP_COMPRESSION_DATES["Test"] = CrashProofer_GetFullTimeStamp()
    table.insert(CP_DB["Test"],{Type="Time",Data="1"})
    table.insert(CP_DB["Test"],{Type="Time",Data="2"})
    table.insert(CP_DB["Test"],{Type="Time",Data="3"})
    table.insert(CP_DB["Test"],{Type="Time",Data="4"})
    table.insert(CP_DB["Test"],{Type="Time",Data="5"})
    --Announce test data.
    CrashProofer_AnnounceOne("Test")
end

function CrashProofer_AddonHasData(addonName)
    if (CP_DB[addonName] == nil) then return false end
    if (#CP_DB[addonName] == 0) then return false end
    
    return true
end

function CrashProofer_GetCompressionDate(addonName)
    if (CP_COMPRESSION_DATES[addonName] ~= nil) then
        --Parse out the timestamp into a legible format.
        local s = CP_COMPRESSION_DATES[addonName]
        local date = string.sub(s,5,6).."/"..string.sub(s,7,8).."/"..string.sub(s,1,4).." "..string.sub(s,9,10)..":"..string.sub(s,11,12)
        return date
    else
        return "None"
    end
end

--Runs all the records, in order, for a given addon's current data table.
--You might use this for someone who had previous CP data for an addon, but
--only just installed the addon for themselves.
function CrashProofer_DoFullRecordFunctionSweep(addonName)
    CP_LAST_RECORD_FUNCTION_RUN[addonName] = 0
    for idx,record in ipairs(CP_DB[addonName]) do
        if (CP_RECORD_FUNCTIONS[addonName][record.Type] ~= nil) then
            CP_RECORD_FUNCTIONS[addonName][record.Type](record)
            CP_LAST_RECORD_FUNCTION_RUN[addonName] = CP_LAST_RECORD_FUNCTION_RUN[addonName] + 1
        end
    end
end

function CrashProofer_OnAddonLoaded(addonName)
    if (addonName == "CrashProofer") then
        CrashProofer_Init()
    else
        CP_ADDONS_LOADED[addonName] = true
        if (CP_DB[addonName] == nil) then return end

        --If we've never run a record function for this addon, make note of it.
        if (CP_LAST_RECORD_FUNCTION_RUN[addonName] == nil) then
            CP_LAST_RECORD_FUNCTION_RUN[addonName] = 0
        end

        --Now that this addon has been loaded, see if any record functions for it were waiting to be called.
        if (CP_LAST_RECORD_FUNCTION_RUN[addonName] < #CP_DB[addonName]) then
            local startRecord = CP_LAST_RECORD_FUNCTION_RUN[addonName]+1
            for i=startRecord,#CP_DB[addonName] do
                --Since the addon has been loaded, its record functions will have been loaded too.
                local record = CP_DB[addonName][i]
                if (CP_RECORD_FUNCTIONS[addonName][record.Type] ~= nil) then
                    CP_RECORD_FUNCTIONS[addonName][record.Type](record)
                end
                CP_LAST_RECORD_FUNCTION_RUN[addonName] = CP_LAST_RECORD_FUNCTION_RUN[addonName]+1
            end
        end
    end
end

function CrashProofer_OnUpdate()
    for addonName,recordIndex in pairs(CP_RECORD_REQUESTS) do
        if (#CP_DB[addonName] >= recordIndex) then
            CrashProofer_SendRecord(addonName,recordIndex)
            CP_RECORD_REQUESTS[addonName] = recordIndex+1
        else
            CP_RECORD_REQUESTS[addonName] = nil
        end
    end
end

function D(s)
    DEFAULT_CHAT_FRAME:AddMessage(s)
end

function CP_FullWipe()
    CP_DB = {}
    CP_COMPRESSION_DATES = {}
    CP_LAST_RECORD_FUNCTION_RUN = {}
	CP_RECORDS_EXPECTED = {}
end

function CrashProofer_CanAddRecords(addonName)
	return (GetTime() > CP_CAN_ADD_RECORDS[addonName]) and (#CP_DB[addonName] == CP_RECORDS_EXPECTED[addonName])
end
